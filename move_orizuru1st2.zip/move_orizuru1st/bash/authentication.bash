#!/usr/bin/bash
 
#ここはコメントです。
sudo chmod a+rw /dev/ttyACM-Arduino01
sudo chmod a+rw /dev/ttyACM-MBED01
sudo chmod a+rw /dev/ttyACM-MBED02
sudo chmod 777 /dev/Kondo_USB-RS485_converter
sudo chmod 777 /dev/ttyUSB-RK2
sudo chmod 777 /dev/ttyUSB-AZ
#処理を終了します。
exit 0