#!/bin/bash
set -e

python2 /opt/ros/melodic/lib/rosserial_python/serial_node.py _port:=/dev/ttyACM-Arduino01 _baud:=57600 &
pids[0]=$!
python2 /opt/ros/melodic/lib/rosserial_python/serial_node2.py _port:=/dev/ttyACM-MBED01 &
pids[1]=$!
python2 /opt/ros/melodic/lib/rosserial_python/serial_node3.py _port:=/dev/ttyACM-MBED02 &
pids[2]=$!
python src/test_gui/scripts/test_gui.py&
pids[3]=$!
roslaunch test_talker test_talker.launch&
pids[4]=$!
roslaunch robot_posture_control robot_posture_control.launch&
pids[5]=$!
roslaunch probe_v2_control probe_v2_control.launch&
pids[6]=$!
roslaunch get_probe_posture get_probe_posture.launch&
pids[7]=$!

wait ${pids[0]}
wait ${pids[1]}
wait ${pids[2]}
wait ${pids[3]}
wait ${pids[4]}
wait ${pids[5]}
wait ${pids[6]}
wait ${pids[7]}