#!/bin/bash
set -e

# sudo chmod a+rw /dev/ttyACM-Arduino01
sudo chmod a+rw /dev/ttyACM-MBED01
sudo chmod 777 /dev/Kondo_USB-RS485_converter
sudo chmod 777 /dev/ttyUSB-RK2
sudo chmod 777 /dev/ttyUSB-AZ

roslaunch om_modbus_master om_modbusRTU.launch com:="/dev/ttyUSB-RK2" topicID:=1 baudrate:=115200 updateRate:=1000 firstGen:="1,2,3,4"&
pids[0]=$!
roslaunch om_modbus_master om_modbusRTU2.launch com:="/dev/ttyUSB-AZ" topicID:=1 baudrate:=115200 updateRate:=1000 firstGen:="5,6,7"&
pids[1]=$!
python2 src/kondo_b3mservo_rosdriver/scripts/probe_velocity_control.py &
pids[2]=$!

wait ${pids[0]}
wait ${pids[1]}
wait ${pids[2]}