#!/usr/bin/bash
 
#ここはコメントです。
python2 /opt/ros/melodic/lib/rosserial_python/serial_node.py _port:=/dev/ttyACM-Arduino01 _baud:=57600

#処理を終了します。
exit 0