#!/bin/bash
set -e

# sudo chmod a+rw /dev/ttyACM-Arduino01
sudo chmod a+rw /dev/ttyACM-MBED01
sudo chmod 777 /dev/Kondo_USB-RS485_converter
sudo chmod 777 /dev/ttyUSB-RK2
sudo chmod 777 /dev/ttyUSB-AZ

roslaunch om_modbus_master om_modbusRTU.launch com:="/dev/ttyUSB-RK2" topicID:=1 baudrate:=115200 updateRate:=1000 firstGen:="1,2,3,4"&
pids[0]=$!
roslaunch robot_posture_control robot_posture_control.launch&
pids[1]=$!
python src/test_gui/scripts/0913_gui.py &
pids[2]=$!

wait ${pids[0]}
wait ${pids[1]}
wait ${pids[2]}