#!/usr/bin/bash
 
#ここはコメントです。
python2 /opt/ros/melodic/lib/rosserial_python/serial_node2.py _port:=/dev/ttyACM-MBED01

#処理を終了します。
exit 0