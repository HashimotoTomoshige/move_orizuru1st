#!/usr/bin/bash
 
#ここはコメントです。
python2 src/kondo_b3mservo_rosdriver/scripts/position_control.py

#処理を終了します。
exit 0